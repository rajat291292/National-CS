﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Windows.Forms;
using System.Web.Security;
using Final_National.Models;

namespace Final_National.Controllers
{
    public class HomeController : Controller
    {

        casestudyEntities db = new casestudyEntities();
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        //public ActionResult Contact()
        //{
        //    ViewBag.Message = "Your contact page.";

        //    return View();
        //}

            

        [HttpGet]
        public ActionResult UserLogin()
        {
            return View();
        }

        [HttpPost]
        public ActionResult UserLogin(login UserAuthenticate)
        {
            if (ModelState.IsValid)
            {

                var obj = db.logins.Where(a => a.username.Equals(UserAuthenticate.username) && a.passwords.Equals(UserAuthenticate.passwords)).FirstOrDefault();
                if (obj != null)
                {
                    Session["UserID"] = obj.login_id;
                    Session["UserName"] = obj.username.ToString();
                    //Session["Name"] = obj.tblPatientDetail.cFirstName + " " + obj.tblPatientDetail.cLastName;
                    return RedirectToAction("Index","tasks");
                }
                else
                {
                    MessageBox.Show("Login Credentials are incorrect please try again");
                }


            }

            return View(UserAuthenticate);
        }

        public ActionResult Sample()
        {
            return View();
        }

    }
}
    
